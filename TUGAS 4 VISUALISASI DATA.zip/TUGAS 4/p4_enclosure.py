#IKHWAN WAHYUDIN
# 1305210065

import json
import plotly
import urllib.request
import ipywidgets as widgets
from anytree import PostOrderIter
from anytree.importer import DictImporter
import plotly.graph_objs as go
import pandas as pd
# Mengunduh data dari URL
url = 'https://www.cs.purdue.edu/CS49000-VIZ/projects/data/project4/flare.json'
response = urllib.request.urlopen(url)
js_data = json.loads(response.read())

#imports dictionary in a tree form
importer = DictImporter()
root = importer.import_(js_data)

size = []
name = []
parent = []
level = []

def format(node):
   for i in node.children:
      #periksa apakah simpul sebagai nilai atribut
      if hasattr(i, 'value') == False:
         format(i)
      v = i.value
      #periksa apakah induk simpul sebagai nilai atribut
      if hasattr(i.parent, 'value') == True :
         i.parent.value += v
      #jika induk simpul tidak memiliki nilai yang disetel ke val yang sama dengan anak
      elif hasattr(i.parent, 'value')== False:
         i.parent.value = v
      level.append(len(i.ancestors))
      name.append(i.name)
      parent.append(i.parent.name)
      size.append(i.value)

      
format(root)

#append atributes for root
level.append(0)
name.append(root.name)
parent.append("")
size.append(root.value)

#create df
df = pd.DataFrame()
df['parent'] = parent
df['name'] = name
df['value'] = size
df['level'] = level

#Slider Function
def update(sliderVal):
    fig = plotly.graph_objs.Figure()
    fig.add_trace(plotly.graph_objs.Treemap(
        labels = df[df['level']<sliderVal]['name'],
        values = df[df['level']<sliderVal]['value'],
        parents = df[df['level']<sliderVal]['parent']
    ))
    fig.update_traces(root_color ="lightblue")
    fig.update_layout(width = 900, height = 900)
    fig.show()


widgets.interact(update, sliderVal = (0, 5))