# %% [markdown]
# PUTRI EKA LESTARI - 1305210067
# 
# TASK 2 - LAYERED DIAGRAMS

# %%
import networkx as nx
import matplotlib.pyplot as plt
import ipywidgets as widgets
import urllib.request
import json
from anytree.importer import DictImporter
from anytree import Node, RenderTree, AsciiStyle, PreOrderIter, PostOrderIter
import matplotlib.cm as cm
from matplotlib.patches import Rectangle
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Circle
from matplotlib.patches import Wedge

# %%
# Mengunduh data dari URL
url = 'https://www.cs.purdue.edu/CS49000-VIZ/projects/data/project4/flare.json'
response = urllib.request.urlopen(url)
data_js = json.loads(response.read())

# %%
#Membuat Graph
importer = DictImporter()
root = importer.import_(data_js)

children_chil = [root]
cols = {}
for j in children_chil:
    #print('y',j)
    c = 0
    for i in PostOrderIter(j):
        try :
            c += i.value
        except AttributeError:
            continue
    cols[j.name] = c
    try:
        #print((list(j.children)))
        children_chil+=(list(j.children))
    except:
        continue

node_lis = []
edge_lis = []
col_lis = []

# %%
#Menambah Node dan Link untuk List pada koneksi 
def detail_json(parent, data):
    now = parent
    if now != None:
        edge_lis.append((parent, data['name']))
   
    col_lis.append(cols[data['name']])
    node_lis.append(data['name'])
    if 'children' in data:
        for i in data['children']:
            detail_json(data['name'],i)
        
    else:
        return
  
detail_json(None, data_js)


G = nx.DiGraph()
G.add_nodes_from(node_lis)
G.add_edges_from(edge_lis)



sub = nx.shortest_path_length(G, 'flare')

# %%
#ENTER VALUE FROM 0-5
Value = 5

sub = nx.shortest_path_length(G, 'flare')
fig, ax = plt.subplots(figsize=(20,20))


plt.xlim([0, 10])
plt.ylim([0, 100])
sub = nx.shortest_path_length(G, 'flare')

importer = DictImporter()
root = importer.import_(data_js)
pat = {}
max_val = 956129
def detail_json2(parent, data, value):     
    now = parent
    if sub[data.name] >= value:
        return
    if now == None:
        ax.add_patch(Rectangle((0, 0), 2, 100, edgecolor= 'grey', facecolor=cm.RdBu(1)))
        pat[data.name]=[(0,0), 2, 100]
    elif now !=None:
        gr_info_p = pat[parent]
        size_num_p = cols[parent]
        level = sub[parent]
        node_size = cols[data.name]
        x = (level + 1)*2
        size_perc = (cols[data.name]/max_val)*100
        y = gr_info_p[0][1] 
        ax.add_patch(Rectangle((x,y),2,size_perc, edgecolor ='grey', facecolor=cm.RdBu(node_size/max_val)))
        t = [(gr_info_p[0][0], gr_info_p[0][1]+size_perc), gr_info_p[1], gr_info_p[2]]
        pat[parent] = t
        pat[data.name] = [(x,y),2,size_perc]


   
    if len(data.children) == 0:
        return
    
    for i in data.children:

            detail_json2(i.parent.name,i, value)
            
    return 

detail_json2(None, root, Value)
c = plt.get_cmap("RdBu")
m = ScalarMappable(Normalize(min(col_lis), max(col_lis)), c)

clb = plt.colorbar(m)

#legend
plt.show()


# %%
Value = 5
fig1, ax1 = plt.subplots(figsize=(20,15))


plt.xlim([-30, 30])
plt.ylim([-30, 30])
sub = nx.shortest_path_length(G, 'flare')


importer = DictImporter()
root = importer.import_(data_js)
pat = {}
max_val = 956129
d = 0
def detail_json3(parent, data, value):
    now = parent
    if now == None:
        ax1.add_patch(Circle((0, 0),radius=5,edgecolor= 'grey', facecolor=cm.RdBu(1)))
        pat[data.name]=0
    if sub[data.name] >= value:
        return
    elif now !=None:
        deg_0 = pat[parent]
        size_num_p = cols[parent]
        level = sub[parent]
        node_size = cols[data.name]
        r = (level + 2)*5
        size_perc = (cols[data.name]/max_val)*360
        theta1 = deg_0
        theta2 = deg_0 + size_perc
        ax1.add_patch(Wedge((0, 0),r=r, theta1=theta1,theta2= theta2,edgecolor= 'grey', facecolor=cm.RdBu(node_size/max_val), width =5))
        pat[parent] = theta2
        pat[data.name] = theta1
   
    if len(data.children) == 0:
        return
    
    for i in data.children:
            detail_json3(i.parent.name,i, value)
            
   
    return 

detail_json3(None, root, Value)
c = plt.get_cmap("RdBu")
m = ScalarMappable(Normalize(min(col_lis), max(col_lis)), c)

clb = plt.colorbar(m)

plt.show()


