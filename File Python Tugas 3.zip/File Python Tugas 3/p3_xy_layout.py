# %% [markdown]
# TASK 1
# Putri Eka Lestari - 1305210067

# %%
import json
import requests
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import plotly.graph_objects as go

# %%
#Download file json
url = "https://www.cs.purdue.edu/CS49000-VIZ/projects/data/project3/USAir97v2.json"
req = requests.get(url)
files = json.loads(req.text)

# %%
#Membuat graph dan variabel untuk node dan edge
nodes = files["nodes"]
edges = files["links"]

graph = nx.Graph()

# %%
#Menambahkan node dan edge kedalam graph
for node in nodes:
    graph.add_node(
        node["id"],
        coords=(node["posx"], node["posy"]),
        label=node["state"])

for edge in edges:
    graph.add_edge(edge["source"], edge["target"])

# %%
withCoords = nx.get_node_attributes(graph, "coords")

edgeX2 = [pos[0] for edge in graph.edges() for pos in [withCoords[edge[0]], withCoords[edge[1]], None] if pos is not None]
edgeY2 = [pos[1] for edge in graph.edges() for pos in [withCoords[edge[0]], withCoords[edge[1]], None] if pos is not None]

nodeWithCoords = go.Scatter(x=[pos[0] for pos in withCoords.values()], y=[pos[1] for pos in withCoords.values()], mode="markers",
                            marker=dict(size=10, color="brown"), text=[node["state"] for node in nodes], hoverinfo="text")

edgeWithCoords = go.Scatter(x=edgeX2, y=edgeY2, line=dict(width=0.5, color="black"), hoverinfo="none", mode="lines")

# %%
#Visualisasi Graph menggunakan posx dan posy

layout2 = go.Layout(showlegend=False, hovermode="closest", title="With posx and posy")
fig2 = go.Figure(data=[edgeWithCoords, nodeWithCoords], layout=layout2)
fig2.show()

# %% [markdown]
# Jika dilihat dari Graph force dan juga Graph xy dapat disimpulkan bahwa tata letak yang lebih unggul ialah Graph xy dikarenakan posisi node-node sesuai dengan titik koordinat memudahkan kita dalam mengelompokkan node tersebut, seperti terlihat pada visualisasi state hawai kebanyakan berada pada rentang x 0.4 - 0.5 dan y 0.2 - 0.3. Pada Graph force persebaran node menjadi lebih sembarang dan membuat visualisasi nya pun menjadi sulit dibaca.


